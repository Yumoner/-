#ifndef _MQTTKIT_H_
#define _MQTTKIT_H_


#include "Common.h"


//=============================ÅäÖÃ==============================
//===========¿ÉÒÔÌá¹©RTOSµÄÄÚ´æ¹ÜÀí·½°¸£¬Ò²¿ÉÒÔÊ¹ÓÃC¿âµÄ=========
//RTOS
#include <stdlib.h>

#define MQTT_MallocBuffer   malloc

#define MQTT_FreeBuffer     free
//==========================================================


#define MOSQ_MSB(A)         (uint8)((A & 0xFF00) >> 8)
#define MOSQ_LSB(A)         (uint8)(A & 0x00FF)


/*--------------------------------ÄÚ´æ·ÖÅä·½°¸±êÖ¾--------------------------------*/
#define MEM_FLAG_NULL       0
#define MEM_FLAG_ALLOC      1
#define MEM_FLAG_STATIC     2


typedef struct Buffer
{

    uint8   *_data;     //Ð­ÒéÊý¾Ý

    uint32  _len;       //Ð´ÈëµÄÊý¾Ý³¤¶È

    uint32  _size;      //»º´æ×Ü´óÐ¡

    uint8   _memFlag;   //ÄÚ´æÊ¹ÓÃµÄ·½°¸£º0-Î´·ÖÅä  1-Ê¹ÓÃµÄ¶¯Ì¬·ÖÅä        2-Ê¹ÓÃµÄ¹Ì¶¨ÄÚ´æ

} MQTT_PACKET_STRUCTURE;


/*--------------------------------¹Ì¶¨Í·²¿ÏûÏ¢ÀàÐÍ--------------------------------*/
enum MqttPacketType
{

    MQTT_PKT_CONNECT = 1, /**< Á¬½ÓÇëÇóÊý¾Ý°ü */
    MQTT_PKT_CONNACK,     /**< Á¬½ÓÈ·ÈÏÊý¾Ý°ü */
    MQTT_PKT_PUBLISH,     /**< ·¢²¼Êý¾ÝÊý¾Ý°ü */
    MQTT_PKT_PUBACK,      /**< ·¢²¼È·ÈÏÊý¾Ý°ü */
    MQTT_PKT_PUBREC,      /**< ·¢²¼Êý¾ÝÒÑ½ÓÊÕÊý¾Ý°ü£¬Qos 2Ê±£¬»Ø¸´MQTT_PKT_PUBLISH */
    MQTT_PKT_PUBREL,      /**< ·¢²¼Êý¾ÝÊÍ·ÅÊý¾Ý°ü£¬ Qos 2Ê±£¬»Ø¸´MQTT_PKT_PUBREC */
    MQTT_PKT_PUBCOMP,     /**< ·¢²¼Íê³ÉÊý¾Ý°ü£¬ Qos 2Ê±£¬»Ø¸´MQTT_PKT_PUBREL */
    MQTT_PKT_SUBSCRIBE,   /**< ¶©ÔÄÊý¾Ý°ü */
    MQTT_PKT_SUBACK,      /**< ¶©ÔÄÈ·ÈÏÊý¾Ý°ü */
    MQTT_PKT_UNSUBSCRIBE, /**< È¡Ïû¶©ÔÄÊý¾Ý°ü */
    MQTT_PKT_UNSUBACK,    /**< È¡Ïû¶©ÔÄÈ·ÈÏÊý¾Ý°ü */
    MQTT_PKT_PINGREQ,     /**< ping Êý¾Ý°ü */
    MQTT_PKT_PINGRESP,    /**< ping ÏìÓ¦Êý¾Ý°ü */
    MQTT_PKT_DISCONNECT,  /**< ¶Ï¿ªÁ¬½ÓÊý¾Ý°ü */

    //ÐÂÔö

    MQTT_PKT_CMD         /**< ÃüÁîÏÂ·¢Êý¾Ý°ü */

};


/*--------------------------------MQTT QOSµÈ¼¶--------------------------------*/
enum MqttQosLevel
{

    MQTT_QOS_LEVEL0,  /**< ×î¶à·¢ËÍÒ»´Î */
    MQTT_QOS_LEVEL1,  /**< ×îÉÙ·¢ËÍÒ»´Î  */
    MQTT_QOS_LEVEL2   /**< Ö»·¢ËÍÒ»´Î */

};


/*--------------------------------MQTT Á¬½ÓÇëÇó±êÖ¾Î»£¬ÄÚ²¿Ê¹ÓÃ--------------------------------*/
enum MqttConnectFlag
{

    MQTT_CONNECT_CLEAN_SESSION  = 0x02,
    MQTT_CONNECT_WILL_FLAG      = 0x04,
    MQTT_CONNECT_WILL_QOS0      = 0x00,
    MQTT_CONNECT_WILL_QOS1      = 0x08,
    MQTT_CONNECT_WILL_QOS2      = 0x10,
    MQTT_CONNECT_WILL_RETAIN    = 0x20,
    MQTT_CONNECT_PASSORD        = 0x40,
    MQTT_CONNECT_USER_NAME      = 0x80

};


/*--------------------------------ÏûÏ¢µÄpacket ID£¬¿É×Ô¶¨Òå--------------------------------*/
#define MQTT_PUBLISH_ID         10

#define MQTT_SUBSCRIBE_ID       20

#define MQTT_UNSUBSCRIBE_ID     30


/*--------------------------------É¾°ü--------------------------------*/
void MQTT_DeleteBuffer(MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------½â°ü--------------------------------*/
uint8 MQTT_UnPacketRecv(uint8 *dataPtr);

/*--------------------------------µÇÂ¼×é°ü--------------------------------*/
uint8 MQTT_PacketConnect(const int8 *user, const int8 *password, const int8 *devid,
                        uint16 cTime, uint1 clean_session, uint1 qos,
                        const int8 *will_topic, const int8 *will_msg, int32 will_retain,
                        MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------¶Ï¿ªÁ¬½Ó×é°ü--------------------------------*/
uint1 MQTT_PacketDisConnect(MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------Á¬½ÓÏìÓ¦½â°ü--------------------------------*/
uint8 MQTT_UnPacketConnectAck(uint8 *rev_data);

/*--------------------------------Êý¾ÝµãÉÏ´«×é°ü--------------------------------*/
uint1 MQTT_PacketSaveData(const int8 *devid, int16 send_len, int8 *type_bin_head, uint8 type, MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------¶þ½øÖÆÎÄ¼þÉÏ´«×é°ü--------------------------------*/
uint1 MQTT_PacketSaveBinData(const int8 *name, int16 file_len, MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------ÃüÁîÏÂ·¢½â°ü--------------------------------*/
uint8 MQTT_UnPacketCmd(uint8 *rev_data, int8 **cmdid, int8 **req, uint16 *req_len);

/*--------------------------------ÃüÁî»Ø¸´×é°ü--------------------------------*/
uint1 MQTT_PacketCmdResp(const int8 *cmdid, const int8 *req, MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------¶©ÔÄÖ÷Ìâ×é°ü--------------------------------*/
uint8 MQTT_PacketSubscribe(uint16 pkt_id, enum MqttQosLevel qos, const int8 *topics[], uint8 topics_cnt, MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------¶©ÔÄÖ÷Ìâ»Ø¸´½â°ü--------------------------------*/
uint8 MQTT_UnPacketSubscribe(uint8 *rev_data);

/*--------------------------------È¡Ïû¶©ÔÄ×é°ü--------------------------------*/
uint8 MQTT_PacketUnSubscribe(uint16 pkt_id, const int8 *topics[], uint8 topics_cnt, MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------È¡Ïû¶©ÔÄ»Ø¸´½â°ü--------------------------------*/
uint1 MQTT_UnPacketUnSubscribe(uint8 *rev_data);

/*--------------------------------·¢²¼Ö÷Ìâ×é°ü--------------------------------*/
uint8 MQTT_PacketPublish(uint16 pkt_id, const int8 *topic,
                        const int8 *payload, uint32 payload_len,
                        enum MqttQosLevel qos, int32 retain, int32 own,
                        MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------·¢²¼ÏûÏ¢»Ø¸´½â°ü--------------------------------*/
uint8 MQTT_UnPacketPublish(uint8 *rev_data, int8 **topic, uint16 *topic_len, int8 **payload, uint16 *payload_len, uint8 *qos, uint16 *pkt_id);

/*--------------------------------·¢²¼ÏûÏ¢µÄAck×é°ü--------------------------------*/
uint1 MQTT_PacketPublishAck(uint16 pkt_id, MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------·¢²¼ÏûÏ¢µÄAck½â°ü--------------------------------*/
uint1 MQTT_UnPacketPublishAck(uint8 *rev_data);

/*--------------------------------·¢²¼ÏûÏ¢µÄRec×é°ü--------------------------------*/
uint1 MQTT_PacketPublishRec(uint16 pkt_id, MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------·¢²¼ÏûÏ¢µÄRec½â°ü--------------------------------*/
uint1 MQTT_UnPacketPublishRec(uint8 *rev_data);

/*--------------------------------·¢²¼ÏûÏ¢µÄRel×é°ü--------------------------------*/
uint1 MQTT_PacketPublishRel(uint16 pkt_id, MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------·¢²¼ÏûÏ¢µÄRel½â°ü--------------------------------*/
uint1 MQTT_UnPacketPublishRel(uint8 *rev_data, uint16 pkt_id);

/*--------------------------------·¢²¼ÏûÏ¢µÄComp×é°ü--------------------------------*/
uint1 MQTT_PacketPublishComp(uint16 pkt_id, MQTT_PACKET_STRUCTURE *mqttPacket);

/*--------------------------------·¢²¼ÏûÏ¢µÄComp½â°ü--------------------------------*/
uint1 MQTT_UnPacketPublishComp(uint8 *rev_data);

/*--------------------------------ÐÄÌøÇëÇó×é°ü--------------------------------*/
uint1 MQTT_PacketPing(MQTT_PACKET_STRUCTURE *mqttPacket);


#endif
