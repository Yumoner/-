#include "esp8266.h"

unsigned char ESP8266_Buf[128];
unsigned short esp8266_cnt = 0, esp8266_cntPre = 0;
unsigned char a_esp8266_buf;

/**
  * @brief esp8266初始化
  * @param ÎÞ
  * @retval ÎÞ
  */
void ESP8266_Init(void)
{
  ESP8266_Clear();

    printf("1. ²âÊÔATÆô¶¯\r\n");
    while(ESP8266_SendCmd("AT\r\n", "OK"))
        Delay_Ms(500);

    printf("2. ÉèÖÃWiFiÄ£Ê½£¨CWMODE£©\r\n");
    while(ESP8266_SendCmd("AT+CWMODE=1\r\n", "OK"))
        Delay_Ms(500);

    printf("3. AT+CWDHCP\r\n");
    while(ESP8266_SendCmd("AT+CWDHCP=1,1\r\n", "OK"))
        Delay_Ms(500);

    printf("4. Á¬½ÓWiFiÈÈµã£¨CWJAP£©\r\n");
    while(ESP8266_SendCmd(ESP8266_WIFI_INFO, "GOT IP"))
        Delay_Ms(500);

    printf("5. ½¨Á¢TCPÁ¬½Ó£¨CIPSTART£©\r\n");
    while(ESP8266_SendCmd(ESP8266_ONENET_INFO, "CONNECT"))
        Delay_Ms(500);

    printf("6. ESP8266 Init OK\r\n");
}


/**
  * @brief  清空缓存
  * @param  ÎÞ
  * @retval ÎÞ
  */
void ESP8266_Clear(void)
{
    memset(ESP8266_Buf, 0, sizeof(ESP8266_Buf));
}

//等待接收完成

_Bool ESP8266_WaitRecive(void)
{
    if(esp8266_cnt == 0)
        return OUTTIME;

    if(esp8266_cnt == esp8266_cntPre)
    {
        esp8266_cnt = 0;

        return OK;
    }
    else
    {
        esp8266_cntPre = esp8266_cnt;

        return OUTTIME;
    }
}

// 发送命令

_Bool ESP8266_SendCmd(char *cmd, char *res)
{

    unsigned char timeOut = 200;

    USART_SendData(USART3, (unsigned int )cmd);//(unsigned char *)cmd强制类型转换的类型

    while(timeOut--)
    {
        if(ESP8266_WaitRecive() == OK)
        {
            printf("%s",ESP8266_Buf);
            if(strstr((const char *)ESP8266_Buf, res) != NULL)
            {
                ESP8266_Clear();

                return 0;
            }
        }
        Delay_Ms(10);
    }
    return 1;
}

//数据发送

void ESP8266_SendData(unsigned char *data, unsigned short len)
{

    char cmdBuf[32];

    ESP8266_Clear();
    sprintf(cmdBuf, "AT+CIPSEND=%d\r\n", len);
    if(!ESP8266_SendCmd(cmdBuf, ">"))
    {
        USART_SendData(USART3, *data);
    }
}

//获得平台返回的数据

unsigned char *ESP8266_GetIPD(unsigned short timeOut)
{

    char *ptrIPD = NULL;

    do
    {
        if(ESP8266_WaitRecive() == OK)
        {
            ptrIPD = strstr((char *)ESP8266_Buf, "IPD,");
            if(ptrIPD == NULL)
            {

            }
            else
            {
                ptrIPD = strchr(ptrIPD, ':');
                if(ptrIPD != NULL)
                {
                    ptrIPD++;
                    return (unsigned char *)(ptrIPD);
                }
                else
                    return NULL;

            }
        }

        Delay_Ms(5);
    } while(timeOut--);

    return NULL;
}


/**
  * @brief 串口3中断回调函数
  * @param
  * @retval
  */
void USART3_IRQHandler(void)
{
    if(esp8266_cnt >= 255)
    {
        esp8266_cnt = 0;
        memset(ESP8266_Buf,0x00,sizeof(ESP8266_Buf));
        USART_SendData(USART3, (int)"shujuyichu!");//(uint8_t *)

    }
    else
    {
        ESP8266_Buf[esp8266_cnt++] = a_esp8266_buf;

    }


    //a_esp8266_buf=USART_ReceiveData(USART3);
}

    double pows(double base, int exponent)
    {
        double result = 1.0;
        int i = 0;

        for (i = 0; i < exponent; i++)
        {
            result *= base;
        }

        return result;
    }

