#ifndef INIT_THE_FUNCTION_PWM_H_
#define INIT_THE_FUNCTION_PWM_H_

void TIM4_PWMOut_Init( u16 arr, u16 psc, u16 ccp );

//void (*app_start)(void) = 0x0000;



#endif /* INIT_THE_FUNCTION_PWM_H_ */
