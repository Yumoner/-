#include "ch32v30x_conf.h"                  // Device header
#include <string.h>
#include "debug.h"
#include "Usart2.h"
#include "fingerprint.h"
#include "warning.h"
#include "duoji.h"

int ID=0;
SysPara AS608Para;//ָ��ģ��AS608����

//��ʾȷ���������Ϣ
void ShowErrMessage(u8 ensure)
{
//  OLED_ShowCH(5,0,(u8*)EnsureMessage(ensure));
}


//¼ָ��
void Add_FR(void)
{
  u8 ensure, processnum = 0;
  while(1)
  {
    switch (processnum)
    {

        case 0:

            ensure = PS_GetImage();
            if(ensure == 0x00)
            {
                ensure = PS_GenChar(CharBuffer1); //��������
                if(ensure == 0x00)
                {

                    Delay_Ms(500);
                    processnum = 1; //�����ڶ���
                }
                else ShowErrMessage(ensure);
            }
            else ShowErrMessage(ensure);
      break;

    case 1:

      ensure = PS_GetImage();
      if(ensure == 0x00)
      {
        ensure = PS_GenChar(CharBuffer2); //��������
        if(ensure == 0x00)
        {

            Delay_Ms(500);
            processnum = 2; //����������
        }
        else ShowErrMessage(ensure);
      }
      else ShowErrMessage(ensure);
      break;

    case 2:

      ensure = PS_Match();
            ensure = 0x00;
      if(ensure == 0x00)
      {

        processnum = 3; //�������Ĳ�
      }
      else
      {

        ShowErrMessage(ensure);
        processnum = 0; //���ص�һ��
      }
      Delay_Ms(500);
      break;

    case 3:

      Delay_Ms(500);
      ensure = PS_RegModel();
      if(ensure == 0x00)
      {
            Delay_Ms(500);
            processnum = 4; //�������岽
      }
      else
      {
        processnum = 0;
        ShowErrMessage(ensure);
      }
      Delay_Ms(1000);
      break;

    case 4:
      ensure = PS_StoreChar(CharBuffer2, ID); //����ģ��
      if(ensure == 0x00)
      {
//        GPIO_ResetBits(GPIOA, GPIO_Pin_1);
//        Delay_Ms(1000);
        return ;
      }
      else
      {
        processnum = 0;
        ShowErrMessage(ensure);
      }
      break;
    }
    }
}



//ˢָ��
void press_FR(void)
{
  SearchResult seach;
  u8 ensure;
    ensure = PS_GetImage();
    if(ensure == 0x00) //��ȡͼ��ɹ�
    {
      ensure = PS_GenChar(CharBuffer1);
      if(ensure == 0x00) //���������ɹ�
      {
        ensure = PS_HighSpeedSearch(CharBuffer1, 0, 99, &seach);
        if(ensure == 0x00) //�����ɹ�
        {
            open_the_door();
            close_the_door();
        }
        else
        {
            start_warning();
        }
      }
      else

          stop_warning();
    }
}


//void Del_FR(void)
//{
//  u8  ensure;
//  if(menu_z == 3)
//  {
//      ensure = PS_DeletChar(ID, 1); //ɾ������ָ��
//      if(ensure == 0)
//      {
//          LED1_Turn();
//      }
//      else
//          ShowErrMessage(ensure);
//      Delay_ms(1500);
//      menu_z-=1;
//
//  }
//}
