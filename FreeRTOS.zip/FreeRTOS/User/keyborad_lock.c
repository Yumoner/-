#include<debug.h>
#include "lcd.h"
#include "warning.h"
//#include "pic.h"

//从PE8到PE15为矩阵键盘
//参数定义区
//char deposit[6] = {'0', '0', '0', '0', '0', '0'}; //存放按键输入密码
//char  Password[6] = {'1', '2', '3', '4', '5', '6'};  //初始密码设置
//int scan=0;
unsigned char KeyNum;
unsigned int password,cnt=0,errorcnt=0;//cnt作为计数器，用于检测次数是否大于四，防止出错

void GPIOKEY_INIT()
{
       GPIO_InitTypeDef GPIO_InitTypdefStruct;//PC 7 8 9 11    12 13 14 15

       RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

       GPIO_InitTypdefStruct.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_11  | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
       GPIO_InitTypdefStruct.GPIO_Mode = GPIO_Mode_IPU;
       GPIO_InitTypdefStruct.GPIO_Speed = GPIO_Speed_50MHz;
       GPIO_Init(GPIOE, &GPIO_InitTypdefStruct);//C

}


int MatrixKey()//数字确认
{
    int KeyNumber=0;

    GPIO_WriteBit(GPIOD, GPIO_Pin_7, 1);GPIO_WriteBit(GPIOD, GPIO_Pin_8, 1);GPIO_WriteBit(GPIOD, GPIO_Pin_9, 1);GPIO_WriteBit(GPIOD, GPIO_Pin_11, 1);GPIO_WriteBit(GPIOD, GPIO_Pin_12, 1);GPIO_WriteBit(GPIOD, GPIO_Pin_13, 1);GPIO_WriteBit(GPIOD, GPIO_Pin_14, 1);GPIO_WriteBit(GPIOD, GPIO_Pin_15, 1);
   //所有引脚置1(引脚配置当中已经实现)
    GPIO_WriteBit(GPIOD, GPIO_Pin_7, 0);
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_12)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_12)==0);Delay_Ms(20);KeyNumber=1;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_13)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_13)==0);Delay_Ms(20);KeyNumber=5;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_14)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_14)==0);Delay_Ms(20);KeyNumber=9;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_15)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_15)==0);Delay_Ms(20);KeyNumber=13;}


    GPIO_WriteBit(GPIOD, GPIO_Pin_8, 0);
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_12)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_12)==0);Delay_Ms(20);KeyNumber=2;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_13)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_13)==0);Delay_Ms(20);KeyNumber=6;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_14)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_14)==0);Delay_Ms(20);KeyNumber=10;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_15)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_15)==0);Delay_Ms(20);KeyNumber=14;}


    GPIO_WriteBit(GPIOD, GPIO_Pin_9, 0);
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_12)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_12)==0);Delay_Ms(20);KeyNumber=3;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_13)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_13)==0);Delay_Ms(20);KeyNumber=7;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_14)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_14)==0);Delay_Ms(20);KeyNumber=11;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_15)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_15)==0);Delay_Ms(20);KeyNumber=15;}


    GPIO_WriteBit(GPIOD, GPIO_Pin_11, 0);
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_12)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_12)==0);Delay_Ms(20);KeyNumber=4;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_13)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_13)==0);Delay_Ms(20);KeyNumber=8;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_14)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_14)==0);Delay_Ms(20);KeyNumber=12;}
    if(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_15)==0){Delay_Ms(20);while(GPIO_ReadInputDataBit(GPIOD, GPIO_Pin_15)==0);Delay_Ms(20);KeyNumber=16;}

    return KeyNumber;
}

int abq()
{
     KeyNum=MatrixKey();//获取输入的数字
     //LCD_Fill(0,0,LCD_W,LCD_H,RED);//变红说明是成功开门

        if(KeyNum>0)
        {
            if(KeyNum<10)//如果s1到s10按键按下，输入密码    刚开始时输入的keynum不参与计算
            {
                if(cnt<4)
                    {
                        start_warning(); //蜂鸣器按键发声
                        Delay_Ms(100);
                        stop_warning();
                        password*=10; //密码左移
                        password+=KeyNum%10;
                        LCD_ShowIntNum(50,30,password,4,RED,WHITE,16);

                        cnt++;
                    }

            }
            //LCD_ShowNum(2,1,password,4);//相当于输出的内容
            //LCD_ShowString(10,30,"Yumoner",RED,WHITE,16,0);

        }
        if(KeyNum==11)
        {
            if(password==8585)
            {
                //LCD_ShowString(1,14,"OK");
                password=0;
                cnt=0;
               // LCD_ShowNum(2,1,password,4);
                LCD_ShowString(10,10,"OK",RED,GREEN,16,0);
                LCD_Fill(0,0,LCD_W,LCD_H,RED);//变红说明是成功开门

            }
                    else
                    {
                        //LCD_ShowString(1,14,"ER");
                        LCD_ShowString(60,60,"ERROR",RED,WHITE,16,0);
                        password=0;
                        cnt=0;
                     //   LCD_ShowNum(2,1,password,4);
                       // LCD_ShowString(10,20,"scanf_again",RED,WHITE,16,0);
                        Delay_Ms(3000);
                        LCD_Fill(0,0,LCD_W,LCD_H,GREEN);//变红说明是成功开门
                        errorcnt++;
                        if(errorcnt>5)
                            start_warning();Delay_Ms(10000);
                     }
        }
        if(KeyNum==12)
            {
                        password=0;
                        cnt=0;
                       /// LCD_ShowNum(2,1,password,4);

            }
return 1;
}





//LCD_ShowString(10,30,"Yumoner",RED,WHITE,16,0);
//        //LCD_ShowString(10,30,"LCD:",RED,WHITE,16,0);
//       // LCD_ShowIntNum(43,30,LCD_W,3,RED,WHITE,16);
//       // LCD_ShowString(67,30,"*",RED,WHITE,16,0);
//       // LCD_ShowIntNum(76,30,LCD_H,3,RED,WHITE,16);
//        LCD_ShowString(10,50,"BY:2550505",RED,WHITE,16,0);
//        LCD_ShowFloatNum1(20,80,t,4,RED,WHITE,16);









//int rowread(void)//行扫描函数
//{
//if (GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_7)==0)
//            return 1;
//
//if (GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_8)==0)
//            return 2;
//
//if (GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_9)==0)
//            return 3;
//
//if (GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_11)==0)
//            return 4;
//
//return 0;
//}
//
//
////设置读取函数
//char columnread(void)
//{
//int column_flag=0  ;
//char keyvalue=0;
//while(1){
//        GPIO_WriteBit(GPIOD, GPIO_Pin_12, 1);
//        GPIO_WriteBit(GPIOD, GPIO_Pin_13, 1);
//        GPIO_WriteBit(GPIOD, GPIO_Pin_14, 1);
//        GPIO_WriteBit(GPIOD, GPIO_Pin_15, 1);
//
//        //第一列判断
//        GPIO_WriteBit(GPIOD, GPIO_Pin_12, 0);
//        if((column_flag=rowread())!=0)//判断是否有键按下
//        {
//          while(rowread()!=0);
//       switch(column_flag)
//            {
//            case 1:keyvalue = '1'; break;
//
//            case 2:keyvalue = '2'; break;
//
//            case 3:keyvalue = '3'; break;
//
//            case 4:keyvalue = 'A'; break;
//            }
//
//       start_warning(); //蜂鸣器按键发声
//       Delay_Ms(100);
//       stop_warning();
//         if(keyvalue =='1'|keyvalue =='2'|keyvalue =='3'|keyvalue =='A')
//         return keyvalue;
//        }
//        GPIO_WriteBit(GPIOD, GPIO_Pin_12, 1);
//
//
//        //第二列判断
//        GPIO_WriteBit(GPIOD, GPIO_Pin_13, 0);
//        if((column_flag=rowread())!=0)
//        {
//           while(rowread()!=0);
//          switch(column_flag)
//            {
//            case 1:keyvalue = '4'; break;
//
//            case 2:keyvalue = '5'; break;
//
//            case 3:keyvalue = '6'; break;
//
//            case 4:keyvalue = 'B'; break;
//            }
//
////         GPIO_WriteBit(GPIOA, GPIO_Pin_1, 1); //按键声
////         Delay_Ms(100);
////         GPIO_WriteBit(GPIOA, GPIO_Pin_1,0);
//     if(keyvalue =='4'|keyvalue =='5'|keyvalue =='6'|keyvalue =='B')
//         return keyvalue;
//        }
//        GPIO_WriteBit(GPIOD, GPIO_Pin_13, 1);
//
//
//
//        //第三列判断
//        GPIO_WriteBit(GPIOD, GPIO_Pin_14, 0);
//        if((column_flag=rowread())!=0)
//        {
//         while(rowread()!=0);
//         switch(column_flag)
//            {
//            case 1:keyvalue = '7'; break;
//
//            case 2:keyvalue = '8'; break;
//
//            case 3:keyvalue = '9'; break;
//
//            case 4:keyvalue = 'C'; break;
//            }
//
////     GPIO_WriteBit(GPIOA, GPIO_Pin_1, 1); //按键声
////     Delay_Ms(100);
////     GPIO_WriteBit(GPIOA, GPIO_Pin_1, 0);
//          if(keyvalue =='7'|keyvalue =='8'|keyvalue =='9'|keyvalue =='C')
//            return keyvalue;
//        }
//        GPIO_WriteBit(GPIOD, GPIO_Pin_14, 1);
//
//
//        //第四列判断
//        GPIO_WriteBit(GPIOD, GPIO_Pin_15, 0);
//    if((column_flag=rowread())!=0){
//
//   while(rowread()!=0);
//  switch(column_flag)
//            {
//            case 1:keyvalue = '*'; break;
//
//            case 2:keyvalue = '0'; break;
//
//            case 3:keyvalue = '#'; break;
//
//            case 4:keyvalue = 'D'; break;
//            }
//
////  GPIO_WriteBit(GPIOA, GPIO_Pin_1, 1); //按键声
////  Delay_Ms(100);
////  GPIO_WriteBit(GPIOA, GPIO_Pin_1, 0);
//       if(keyvalue =='*'|keyvalue =='0'|keyvalue =='#'|keyvalue =='D')
//         return keyvalue;
//    }
//    GPIO_WriteBit(GPIOD, GPIO_Pin_15, 1);
//}
//}
//
////
//void judge(void)
//{
//    //LCD_Fill(0,0,LCD_W,LCD_H,BLUE);
//    //LCD_ShowString(0,30,"put_the_password",RED,WHITE,16,0);
//    int asc=0;
//        deposit[0]=columnread();
//        asc=deposit[0];
//        LCD_ShowIntNum(2,0,asc-32,3,RED,WHITE,10);//后面三个都是没有用的
//        LCD_Fill(0,0,LCD_W,LCD_H,RED);
//        //OLED_Draw_16_8_ASCII(2,0,asc-32);
//        deposit[1]=columnread();
//            asc=deposit[1];
//            LCD_ShowIntNum(2,8,asc-32,3,RED,WHITE,10);//后面三个都是没有用的
//        //OLED_Draw_16_8_ASCII(2,8,asc-32);
//        deposit[2]=columnread();
//            asc=deposit[2];
//            LCD_ShowIntNum(2,16,asc-32,3,RED,WHITE,10);//后面三个都是没有用的
//        //OLED_Draw_16_8_ASCII(2,16,asc-32);
//        deposit[3]=columnread();
//            asc=deposit[3];
//            LCD_ShowIntNum(2,24,asc-32,3,RED,WHITE,10);//后面三个都是没有用的
//        //OLED_Draw_16_8_ASCII(2,24,asc-32);
//        deposit[4]=columnread();
//            asc=deposit[4];
//            LCD_ShowIntNum(2,32,asc-32,3,RED,WHITE,10);//后面三个都是没有用的
//        //OLED_Draw_16_8_ASCII(2,32,asc-32);
//        deposit[5]=columnread();
//            asc=deposit[5];
//            LCD_ShowIntNum(2,40,asc-32,3,RED,WHITE,10);//后面三个都是没有用的
//        //OLED_Draw_16_8_ASCII(2,40,asc-32);
//               while(columnread()!='#');
//
//         if((deposit[0] == Password[0]) & (deposit[1] == Password[1]) & (deposit[2] == Password[2])
//           & (deposit[3] == Password[3]) & (deposit[4] == Password[4]) & ( deposit[5] == Password[5]))
//         {
//             for(int i=5;i<7;i++)
//            {
//          // OLED_Draw_16_16_Hz(4,(i-5)*16,i);
//            }
//               scan=1;
//               Delay_Ms(2000);
//            // OLED_ALL_Clear();
//          }
//    else
//    {
//          for(int i=7;i<9;i++)
//          {
//           //OLED_Draw_16_16_Hz(4,(i-7)*16,i);
//          }
//            Delay_Ms(2000);
//             //OLED_ALL_Clear();
//            for(int i=0;i<5;i++)
//          {
//           //OLED_Draw_16_16_Hz(0,i*16,i);
//          }
//
//    }
//}

