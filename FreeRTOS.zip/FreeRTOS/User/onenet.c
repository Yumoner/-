#include "onenet.h"
#include "debug.h"
#include <string.h>
#include <stdio.h>
#include <duoji.h>

//CJSON¿â
#include "cJSON.h"

#define PROID       "609344"            //产品ID
#define AUTH_INFO   "5278900"           //鉴权信息
#define DEVID       "1096365831"            //设备ID

//extern unsigned char esp8266_buf[128];

float sht20_info_tempreture = 12;
float sht20_info_humidity = 15;

//extern int tempreture;
//extern int humidity;


_Bool OneNet_DevLink(void)
{

    MQTT_PACKET_STRUCTURE mqttPacket = {NULL, 0, 0, 0};

    unsigned char *dataPtr;

    _Bool status = 1;

    printf("OneNet_DevLink\r\n"
                            "PROID: %s, AUIF: %s,   DEVID:%s\r\n"
                        , PROID, AUTH_INFO, DEVID);

    if(MQTT_PacketConnect(PROID, AUTH_INFO, DEVID, 256, 0, MQTT_QOS_LEVEL0, NULL, NULL, 0, &mqttPacket) == 0)
    {
        ESP8266_SendData(mqttPacket._data, mqttPacket._len);
        dataPtr = ESP8266_GetIPD(250);
        if(dataPtr != NULL)
        {
            if(MQTT_UnPacketRecv(dataPtr) == MQTT_PKT_CONNACK)
            {
                switch(MQTT_UnPacketConnectAck(dataPtr))
                {
                    case 0:printf("Tips:    Á¬½Ó³É¹¦\r\n");status = 0;break;

                    case 1:printf("WARN:    Á¬½ÓÊ§°Ü£ºÐ­Òé´íÎó\r\n");break;
                    case 2:printf("WARN:    Á¬½ÓÊ§°Ü£º·Ç·¨µÄclientid\r\n");break;
                    case 3:printf("WARN:    Á¬½ÓÊ§°Ü£º·þÎñÆ÷Ê§°Ü\r\n");break;
                    case 4:printf("WARN:    Á¬½ÓÊ§°Ü£ºÓÃ»§Ãû»òÃÜÂë´íÎó\r\n");break;
                    case 5:printf("WARN:    Á¬½ÓÊ§°Ü£º·Ç·¨Á´½Ó(±ÈÈçtoken·Ç·¨)\r\n");break;

                    default:printf("ERR:    Á¬½ÓÊ§°Ü£ºÎ´Öª´íÎó\r\n");break;
                }
            }
        }

        MQTT_DeleteBuffer(&mqttPacket);
    }
    else
        printf("WARN:   MQTT_PacketConnect Failed\r\n");

    return status;

}

unsigned char OneNet_FillBuf(char *buf)
{

    char text[32];
    uint16_t LED1_FLAG = !GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_5);

    memset(text, 0, sizeof(text));
    strcpy(buf, ",;");

    memset(text, 0, sizeof(text));
    //sprintf(text, "Tempreture,%d;", tempreture);
    strcat(buf, text);
//
//  memset(text, 0, sizeof(text));
//  sprintf(text, "Humidity,%d;", humidity);
//  strcat(buf, text);

//  memset(text, 0, sizeof(text));
//  sprintf(text, "key:%d;", LED1_FLAG);
//  strcat(buf, text);

    memset(text, 0, sizeof(text));
    sprintf(text, "LED,%d", LED1_FLAG);
    strcat(buf, text);
    printf("buf_mqtt=%s\r\n",buf);


    return strlen(buf);

}

//unsigned char OneNet_FillBuf(char *buf)
//{
//
//  char text[32];
//  uint16_t LED1_FLAG = !HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_5);      //¶ÁÈ¡µ±Ç°LED1µÄ×´Ì¬
//
//  memset(text, 0, sizeof(text));
//
//  strcpy(buf, "{");
//
//  memset(text, 0, sizeof(text));
//  sprintf(text, "Tempreture:%d,", tempreture);
//  strcat(buf, text);
//
//  memset(text, 0, sizeof(text));
//  sprintf(text, "Humidity:%d,",humidity);
//  strcat(buf, text);
//
//  memset(text, 0, sizeof(text));
//  sprintf(text, "LED:%d", LED1_FLAG);
//  strcat(buf, text);
//
//  strcat(buf, "}");
//
//  return strlen(buf);
//

//}


//==========================================================
//  º¯ÊýÃû³Æ£º  OneNet_SendData
//
//  º¯Êý¹¦ÄÜ£º  ÉÏ´«Êý¾Ýµ½Æ½Ì¨
//
//  Èë¿Ú²ÎÊý£º  type£º·¢ËÍÊý¾ÝµÄ¸ñÊ½
//
//  ·µ»Ø²ÎÊý£º  ÎÞ
//
//  ËµÃ÷£º
//==========================================================
void OneNet_SendData(void)
{

    MQTT_PACKET_STRUCTURE mqttPacket = {NULL, 0, 0, 0};

    char buf[128];

    short body_len = 0, i = 0;

    printf("Tips:   OneNet_SendData-MQTT\r\n");

    memset(buf, 0, sizeof(buf));

    body_len = OneNet_FillBuf(buf);

    if(body_len)
    {
        if(MQTT_PacketSaveData(DEVID, body_len, NULL, 5, &mqttPacket) == 0)
        {
            for(; i < body_len; i++)
                mqttPacket._data[mqttPacket._len++] = buf[i];

            ESP8266_SendData(mqttPacket._data, mqttPacket._len);
            printf("Send %d Bytes\r\n", mqttPacket._len);

            MQTT_DeleteBuffer(&mqttPacket);
        }
        else
            printf("WARN:   EDP_NewBuffer Failed\r\n");
    }

}

//平台返回数据检测

//void OneNet_RevPro(unsigned char *cmd)
//{
//
//  MQTT_PACKET_STRUCTURE mqttPacket = {NULL, 0, 0, 0};
//
//  char *req_payload = NULL;
//  char *cmdid_topic = NULL;
//
//  unsigned short req_len = 0;
//
//  unsigned char type = 0;
//
//  short result = 0;

//  char *dataPtr = NULL;
//  char numBuf[10];
//  int num = 0;
//
//  type = MQTT_UnPacketRecv(cmd);
//  switch(type)
//  {
//      case MQTT_PKT_CMD:
//
//          result = MQTT_UnPacketCmd(cmd, &cmdid_topic, &req_payload, &req_len);
//          if(result == 0)
//          {
//              printf("cmdid: %s, req: %s, req_len: %d\r\n", cmdid_topic, req_payload, req_len);
//
//              if(MQTT_PacketCmdResp(cmdid_topic, req_payload, &mqttPacket) == 0)
//              {
//                  printf("Tips:   Send CmdResp\r\n");
//
//                  ESP8266_SendData(mqttPacket._data, mqttPacket._len);            //»Ø¸´ÃüÁî
//                  MQTT_DeleteBuffer(&mqttPacket);                                 //É¾°ü
//              }
//          }
//
//      break;
//
//      case MQTT_PKT_PUBACK:                                                       //·¢ËÍPublishÏûÏ¢£¬Æ½Ì¨»Ø¸´µÄAck
//
//          if(MQTT_UnPacketPublishAck(cmd) == 0)
//              printf("Tips:   MQTT Publish Send OK\r\n");
//
//      break;
//
//      default:
//          result = -1;
//      break;
//  }
//
//  ESP8266_Clear();                                    //Çå¿Õ»º´æ
//
//  if(result == -1)
//      return;
//
//  dataPtr = strchr(req_payload, ':');                 //ËÑË÷':'²ÅÄÜ¹»³öÏÖÊý×Ö

//  if(dataPtr != NULL && result != -1)                 //Èç¹ûÕÒµ½ÁË
//  {
//      dataPtr++;
//
//      while(*dataPtr >= '0' && *dataPtr <= '9')       //ÅÐ¶ÏÊÇ·ñÊÇÏÂ·¢µÄÃüÁî¿ØÖÆÊý¾Ý
//      {
//          numBuf[num++] = *dataPtr++;
//      }
//      numBuf[num] = 0;
//              num = atoi((const char *)numBuf);               //×ªÎªÊýÖµÐÎÊ½

//      /*´¦ÀíÔÆ¶ËÏÂ·¢ÃüÁîµÄÊý¾Ý*/
//      if(strstr((char *)req_payload, "key"))      //ËÑË÷"LED:"
//  {

//      if(num == 1)                                //¿ØÖÆÊý¾ÝÈç¹ûÎª1£¬´ú±í¿ª
//      {
//           HAL_GPIO_WritePin(GPIOE, GPIO_PIN_5, GPIO_PIN_SET);
//      }
//      else if(num == 0)                           //¿ØÖÆÊý¾ÝÈç¹ûÎª0£¬´ú±í¹Ø
//      {
//           HAL_GPIO_WritePin(GPIOE, GPIO_PIN_5, GPIO_PIN_RESET);
//      }
//  }
//                                                  //ÏÂÍ¬
//  else if(strstr((char *)req_payload, "key1"))
//  {
//      if(num == 1)
//      {
//          printf("1\r\n");
//      }
//      else if(num == 0)
//      {
//          printf("0\r\n");
//      }
//  }

//}
//  if(type == MQTT_PKT_CMD || type == MQTT_PKT_PUBLISH)
//  {
//      MQTT_FreeBuffer(cmdid_topic);
//      MQTT_FreeBuffer(req_payload);
//  }

//}

//同样为检测平台返回数据
void OneNet_RevPro(unsigned char *cmd)
{

    MQTT_PACKET_STRUCTURE mqttPacket = {NULL, 0, 0, 0};

    char *req_payload = NULL;
    char *cmdid_topic = NULL;

    unsigned short topic_len = 0;
    unsigned short req_len = 0;

    unsigned char type = 0;
    unsigned char qos = 0;
    static unsigned short pkt_id = 0;

    short result = 0;

    char *dataPtr = NULL;
    char numBuf[10];
    int num = 0;

    cJSON* cjson;
    int value;

    type = MQTT_UnPacketRecv(cmd);
    switch(type)
    {
        case MQTT_PKT_CMD:

            result = MQTT_UnPacketCmd(cmd, &cmdid_topic, &req_payload, &req_len);
            if(result == 0)
            {
                printf("cmdid: %s, req: %s, req_len: %d\r\n", cmdid_topic, req_payload, req_len);

                if(MQTT_PacketCmdResp(cmdid_topic, req_payload, &mqttPacket) == 0)
                {
                    printf("Tips:   Send CmdResp\r\n");

                    ESP8266_SendData(mqttPacket._data, mqttPacket._len);
                    MQTT_DeleteBuffer(&mqttPacket);
                }
            }

        break;

        case MQTT_PKT_PUBLISH:
            result = MQTT_UnPacketPublish(cmd, &cmdid_topic, &topic_len, &req_payload, &req_len, &qos, &pkt_id);
            if(result == 0)
            {
                printf("topic: %s, topic_len: %d, payload: %s, payload_len: %d\r\n",
                                                                    cmdid_topic, topic_len, req_payload, req_len);




                cjson = cJSON_Parse(req_payload);

                if(cjson == NULL){
//                      printf("json pack into cjson error...");
                      printf("json pack into cjson error...\r\n");
                }
                else{

                //cJSON_GetObjectltem
                value = cJSON_GetObjectItem(cjson,"LED")->valueint;

                if(value)   GPIO_WriteBit(GPIOE, GPIO_Pin_5, 0);
                else  GPIO_WriteBit(GPIOE, GPIO_Pin_5, 1);

                }

                //delete cjson
                cJSON_Delete(cjson);



                switch(qos)
                {
                    case 1:                                                         //ÊÕµ½publishµÄqosÎª1£¬Éè±¸ÐèÒª»Ø¸´Ack

                        if(MQTT_PacketPublishAck(pkt_id, &mqttPacket) == 0)
                        {
                            printf("Tips:   Send PublishAck\r\n");
                            ESP8266_SendData(mqttPacket._data, mqttPacket._len);
                            MQTT_DeleteBuffer(&mqttPacket);
                            open_the_door();
                            Delay_Ms(500);
                            close_the_door();
                        }

                    break;

                    case 2:                                                         //ÊÕµ½publishµÄqosÎª2£¬Éè±¸ÏÈ»Ø¸´Rec
                                                                                    //Æ½Ì¨»Ø¸´Rel£¬Éè±¸ÔÙ»Ø¸´Comp
                        if(MQTT_PacketPublishRec(pkt_id, &mqttPacket) == 0)
                        {
                            printf( "Tips:  Send PublishRec\r\n");
                            ESP8266_SendData(mqttPacket._data, mqttPacket._len);
                            MQTT_DeleteBuffer(&mqttPacket);
                        }

                    break;

                    default:
                        break;
                }
            }

        break;

        case MQTT_PKT_PUBACK:                                                       //·¢ËÍPublishÏûÏ¢£¬Æ½Ì¨»Ø¸´µÄAck

            if(MQTT_UnPacketPublishAck(cmd) == 0)
                printf("Tips:   MQTT Publish Send OK\r\n");

        break;

        default:
            result = -1;
        break;
    }

    ESP8266_Clear();                                    //Çå¿Õ»º´æ

    if(result == -1)
        return;

    dataPtr = strchr(req_payload, '}');                 //ËÑË÷'}'

    if(dataPtr != NULL && result != -1)                 //Èç¹ûÕÒµ½ÁË
    {
        dataPtr++;

        while(*dataPtr >= '0' && *dataPtr <= '9')       //ÅÐ¶ÏÊÇ·ñÊÇÏÂ·¢µÄÃüÁî¿ØÖÆÊý¾Ý
        {
            numBuf[num++] = *dataPtr++;
        }
        numBuf[num] = 0;

        num = atoi((const char *)numBuf);               //×ªÎªÊýÖµÐÎÊ½
    }

    if(type == MQTT_PKT_CMD || type == MQTT_PKT_PUBLISH)
    {
        MQTT_FreeBuffer(cmdid_topic);
        MQTT_FreeBuffer(req_payload);
    }

}

/************************************************************/


//订阅主题
void OneNet_Subscribe(const char *topics[], unsigned char topic_cnt)
{

    unsigned char i = 0;

    MQTT_PACKET_STRUCTURE mqttPacket = {NULL, 0, 0, 0};                         //Ð­Òé°ü

    for(; i < topic_cnt; i++)
//  UsartPrintf(USART_DEBUG, "Subscribe Topic: %s\r\n", topics[i]);
    printf("Subscribe Topic: %s\r\n", topics[i]);
    if(MQTT_PacketSubscribe(MQTT_SUBSCRIBE_ID, MQTT_QOS_LEVEL2, topics, topic_cnt, &mqttPacket) == 0)
    {
        ESP8266_SendData(mqttPacket._data, mqttPacket._len);                    //ÏòÆ½Ì¨·¢ËÍ¶©ÔÄÇëÇó

        MQTT_DeleteBuffer(&mqttPacket);                                         //É¾°ü
    }

}
