
#ifndef WAISHE_DUOJI_H_
#define WAISHE_DUOJI_H_

void Servo_Init();
void open_the_door();
void close_the_door();
void t(float Angle);

#endif /* WAISHE_DUOJI_H_ */
