#ifndef _ESP8266_H_
#define _ESP8266_H_

#include "debug.h"
//#include "usart.h"
#include<string.h>
#include<stdio.h>
#include<stdbool.h>

#define     ESP8266_WIFI_INFO       "AT+CWJAP=\"NJUST\",\"768541ly\"\r\n"          //Á¬½ÓÉÏ×Ô¼ºµÄwifiÈÈµã£ºWiFiÃûºÍÃÜÂë
#define     ESP8266_ONENET_INFO     "AT+CIPSTART=\"TCP\",\"183.230.40.39\",6002\r\n" //Á¬½ÓÉÏOneNetµÄMQTT

#define     OK              0       //½ÓÊÕÍê³É±êÖ¾
#define     OUTTIME         1       //½ÓÊÕÎ´Íê³É±êÖ¾



void ESP8266_Clear(void);           //Çå¿Õ»º´æ

void ESP8266_Init(void);            //esp8266³õÊ¼»¯


_Bool ESP8266_SendCmd(char *cmd, char *res);//·¢ËÍÊý¾Ý

unsigned char *ESP8266_GetIPD(unsigned short timeOut);
void ESP8266_SendData(unsigned char *data, unsigned short len);
double pows(double base, int exponent);

#endif
