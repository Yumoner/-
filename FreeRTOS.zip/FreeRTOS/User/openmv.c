#include "debug.h"
#include <stdio.h>

//变量定义区
int GetOpenmvDataCount  = 0;
uint8_t  shuju1=0, shuju2 =0, Finded_flag = 0, FindTask = 0;//串口里发送的数据
//全局变量
u8 TxBuffer[8] = {0};           //存放着要发送的数据
u8 RxBuffer[8] = {0};           //
//下面两个变量的状态会经常变化
volatile u8 TxCnt = 0, RxCnt = 0;//发送计数与接收计数，用于计算判断发送或者接收是否结束


void Openmv_Receive_Data(uint8_t com_data)//接收数据
{
        uint8_t i;
        static uint8_t RxCounter1=0;//计数
        static uint16_t RxBuffer1[10]={0};   //一般会先收到一个无用的数据
        static uint8_t RxState = 0;    //状态标志位，用于检测接收进程是否正确
        //static uint8_t RxFlag1 = 0;    //暂时未用到

        if(RxState==0&&com_data==0x2C)  //0x2c帧头
        {
            RxState=1;
            RxBuffer1[RxCounter1++]=com_data;
        }

        else if(RxState==1&&com_data==0x12)  //0x12帧头
        {
            RxState=2;
            RxBuffer1[RxCounter1++]=com_data;
        }

        else if(RxState==2)
        {

            RxBuffer1[RxCounter1++]=com_data;
            if(RxCounter1>=10||com_data == 0x5B)       //RxBuffer1接收满了，数据接收结束，此处是帧尾
            {
                RxState=3;
               // RxFlag1=1;

                shuju1 =          RxBuffer1[RxCounter1-5];
                shuju2 =          RxBuffer1[RxCounter1-4];
                Finded_flag =  RxBuffer1[RxCounter1-3];
                FindTask =      RxBuffer1[RxCounter1-2];

                //RxCounter1-1是帧尾
                GetOpenmvDataCount++;
            }
        }

        else if(RxState==3)     //检测是否接受到检测标志
        {
                if(RxBuffer1[RxCounter1-1] == 0x5B)
                {
                            //RxFlag1 = 0;
                            RxCounter1 = 0;
                            RxState = 0;
                }
                else   //接收错误
                {
                            RxState = 0;
                            RxCounter1=0;
                            for(i=0;i<10;i++)
                            {
                                    RxBuffer1[i]=0x00;      //存放的数据组清零
                            }
                }
        }

        else   //接收异常
        {
                RxState = 0;
                RxCounter1=0;
                for(i=0;i<10;i++)
                {
                        RxBuffer1[i]=0x00;      //存放的数据组清零
                }
        }
}



void SendDataToOpenmv(u8 TxBuffer[])//给openmv发数据
{
    u8 i;
    //加上给openmv的帧头，帧尾

        for(i = 0; i <= 7; i++)   //打包发送数据
        {
            USART_SendData(USART2, TxBuffer[TxCnt++]);//Txbuffer存放着发送的数据

        }
}
