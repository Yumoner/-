
#ifndef USER_KEYBORAD_LOCK_H_
#define USER_KEYBORAD_LOCK_H_

void GPIOKEY_INIT();
int MatrixKey();
int rowread(void);
char columnread(void);
void judge(void);
void abq();

#endif /* USER_KEYBORAD_LOCK_H_ */
