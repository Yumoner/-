/*
 * SPI.h
 *
 *  Created on: 2023��6��10��
 *      Author: DELL
 */

#ifndef USER_SPI_H_
#define USER_SPI_H_




#include "debug.h"

void SPI2_Init(void);




#endif /* USER_SPI_H_ */
