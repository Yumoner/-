
#ifndef USER_WARNING_H_
#define USER_WARNING_H_

void start_warning();
void stop_warning();

#endif /* USER_WARNING_H_ */
